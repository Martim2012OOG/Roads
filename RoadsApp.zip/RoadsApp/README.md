# Roads 🧭

App de navegação estilo Waze — Kotlin + Jetpack Compose, mapa OpenStreetMap via
MapLibre (grátis, offline), routing OSRM (grátis, sem key), voz nativa Android
com *ducking* automático de música, e controlo do Spotify em direto.

## O que já funciona
- Mapa limpo (OSM), pesquisa de destino, favoritos (Casa/Trabalho), recentes
- Cálculo de rota (OSRM) + pré-visualização + navegação turn-by-turn
- Voz das indicações (TTS pt-PT), com o volume da música a baixar sozinho quando fala
- Velocímetro, botão de reportar (trânsito, polícia, acidente, radar, etc.)
- Última localização fica guardada e é usada mesmo sem GPS/rede ao abrir a app
- Controlo do Spotify (capa, faixa, play/pause/skip) via App Remote SDK oficial

## Antes de compilares — 2 coisas obrigatórias

### 1. Client ID do Spotify (grátis, 2 min)
1. Vai a https://developer.spotify.com/dashboard → cria uma app (grátis)
2. Em "Redirect URIs" adiciona: `roadsapp://spotify-callback`
3. Nas definições da app, em "Android packages", regista:
   - Package name: `com.roads.app`
   - SHA1 fingerprint: obtém com o comando abaixo (secção Codespaces)
4. Copia o **Client ID** e cola em:
   `app/src/main/java/com/roads/app/music/SpotifyController.kt` → `SpotifyConfig.CLIENT_ID`

Sem isto o resto da app funciona na mesma — só o botão do Spotify não liga.

### 2. Tens de ter a app do Spotify instalada no telemóvel de teste
O App Remote SDK controla a app oficial do Spotify — não faz streaming próprio.

## Compilar no GitHub Codespaces (copia e cola no terminal)

```bash
# 1. Instalar Java 17
sudo apt-get update && sudo apt-get install -y openjdk-17-jdk unzip

# 2. Instalar o Android SDK command-line tools
mkdir -p ~/android-sdk/cmdline-tools
cd ~/android-sdk/cmdline-tools
curl -o tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip tools.zip && mv cmdline-tools latest
rm tools.zip

export ANDROID_HOME=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

# 3. Instalar plataformas e aceitar licenças
yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

# 4. Instalar o Gradle
sudo apt-get install -y gradle

# 5. Ir para a pasta do projeto (depois de descomprimires o zip)
cd RoadsApp

# 6. (Opcional) Obter o SHA1 para registares no Spotify Dashboard
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android | grep SHA1

# 7. Compilar o APK de debug
gradle assembleDebug

# O APK fica em:
# app/build/outputs/apk/debug/app-debug.apk
```

Depois é só descarregar esse `.apk` do Codespaces (botão direito → Download no
explorador de ficheiros) e instalar no telemóvel (ativa "Instalar de origens
desconhecidas" nas definições do Android).

## Arquitetura (porque é tudo grátis e sem limites)
| Peça | Solução usada | Custo |
|---|---|---|
| Mapa | OpenStreetMap tiles via MapLibre | Grátis, sem key |
| Rotas | OSRM demo público (`router.project-osrm.org`) | Grátis — para produção séria, hospeda o teu próprio OSRM |
| Pesquisa de moradas | Nominatim (OSM) | Grátis, exige User-Agent (já incluído) |
| Voz | TextToSpeech nativo do Android | Grátis, offline |
| Música | Spotify App Remote SDK | Grátis, precisa de Client ID |
| Localização offline | SharedPreferences (última posição) | — |

## Próximos passos sugeridos
- Descarregar regiões de mapa para offline total (MapLibre `OfflineManager`)
- Alojar o teu próprio OSRM para tirares o rate-limit do servidor demo
- Base de dados de radares fixos (não existe fonte gratuita nacional oficial —
  terias de importar um CSV de fonte aberta ou deixar só os reportados pelos utilizadores)
