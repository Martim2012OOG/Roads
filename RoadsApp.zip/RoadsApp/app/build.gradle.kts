plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.roads.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.roads.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // Redirect URI usado pelo login do Spotify: roadsapp://spotify-callback
        manifestPlaceholders["redirectSchemeName"] = "roadsapp"
        manifestPlaceholders["redirectHostName"] = "spotify-callback"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    packaging {
        resources.excludes.add("META-INF/*")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")

    // Mapa (OpenStreetMap via MapLibre - sem key, sem limites)
    implementation("org.maplibre.gl:android-sdk:11.0.0")

    // Localização
    implementation("com.google.android.gms:play-services-location:21.3.0")

    // Rede (routing OSRM + geocoding Nominatim)
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.code.gson:gson:2.11.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Spotify App Remote (grátis, requer Client ID no Spotify Developer Dashboard)
    implementation("com.spotify.android:spotify-app-remote:0.8.0")
    implementation("com.spotify.android:auth:2.1.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
