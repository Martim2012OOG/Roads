package com.roads.app.location

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.*
import com.roads.app.data.LatLon
import com.roads.app.data.LocalStore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class NavLocation(
    val latLon: LatLon,
    val speedKmh: Int,
    val bearing: Float
)

class LocationTracker(private val context: Context) {

    private val client: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)
    private val store = LocalStore(context)

    /** Última posição conhecida — usada assim que a app abre, mesmo sem GPS/rede. */
    fun lastKnownOrCached(): LatLon? = store.getLastLocation()

    @SuppressLint("MissingPermission")
    fun observeLocation(intervalMillis: Long = 2000L): Flow<NavLocation> = callbackFlow {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, intervalMillis)
            .setMinUpdateIntervalMillis(1000L)
            .build()

        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                val latLon = LatLon(loc.latitude, loc.longitude)
                store.saveLastLocation(latLon.lat, latLon.lon)
                val speedKmh = (loc.speed * 3.6f).toInt().coerceAtLeast(0)
                trySend(NavLocation(latLon, speedKmh, loc.bearing))
            }
        }

        client.requestLocationUpdates(request, callback, context.mainLooper)

        awaitClose { client.removeLocationUpdates(callback) }
    }
}
