package com.roads.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.roads.app.data.AlertType

private data class AlertOption(
    val type: AlertType,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color
)

private val alertOptions = listOf(
    AlertOption(AlertType.TRANSITO, Icons.Filled.Traffic, Color(0xFFFF7A1F)),
    AlertOption(AlertType.POLICIA, Icons.Filled.LocalPolice, Color(0xFF3E7BFA)),
    AlertOption(AlertType.ACIDENTE, Icons.Filled.CarCrash, Color(0xFFFF4B4B)),
    AlertOption(AlertType.PERIGO, Icons.Filled.Warning, Color(0xFFFFC107)),
    AlertOption(AlertType.CORTE, Icons.Filled.Block, Color(0xFFFF7A1F)),
    AlertOption(AlertType.VIA_CORTADA, Icons.Filled.Construction, Color(0xFFFF7A1F)),
    AlertOption(AlertType.RADAR, Icons.Filled.Speed, Color(0xFF6C4DFF))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlertSheet(
    onDismiss: () -> Unit,
    onAlertChosen: (AlertType) -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp)) {
            Text("Alertar para:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(20.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.height(320.dp)
            ) {
                items(alertOptions) { option ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable {
                                onAlertChosen(option.type)
                                onDismiss()
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF2F2F2)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(option.icon, contentDescription = null, tint = option.color)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            option.type.label,
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
