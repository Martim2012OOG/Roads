package com.roads.app.data

data class LatLon(val lat: Double, val lon: Double)

data class PlaceResult(
    val displayName: String,
    val lat: Double,
    val lon: Double
)

data class RouteStep(
    val instruction: String,
    val distanceMeters: Double,
    val streetName: String,
    val maneuver: String,
    val location: LatLon
)

data class RouteResult(
    val geometry: List<LatLon>,
    val steps: List<RouteStep>,
    val distanceMeters: Double,
    val durationSeconds: Double
)

enum class AlertType(val label: String) {
    TRANSITO("Trânsito"),
    POLICIA("Polícia"),
    ACIDENTE("Acidente"),
    PERIGO("Perigo"),
    CORTE("Corte"),
    VIA_CORTADA("Via cortada"),
    RADAR("Radar de velocidade")
}

data class MapAlert(
    val id: String = java.util.UUID.randomUUID().toString(),
    val type: AlertType,
    val lat: Double,
    val lon: Double,
    val timestampMillis: Long = System.currentTimeMillis(),
    val speedLimitKmh: Int? = null
)

data class FavoritePlace(
    val label: String,
    val address: String,
    val lat: Double,
    val lon: Double
)
