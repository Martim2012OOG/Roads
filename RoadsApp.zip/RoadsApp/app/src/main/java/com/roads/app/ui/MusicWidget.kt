package com.roads.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.roads.app.music.MusicTrackInfo

/** Botões flutuantes (Spotify + volume) que aparecem sobre o mapa, como no Waze. */
@Composable
fun MusicFloatingButtons(
    connected: Boolean,
    onSpotifyClick: () -> Unit,
    onMuteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        FloatingRoundButton(
            icon = Icons.Filled.MusicNote,
            background = if (connected) Color(0xFF1ED760) else Color(0xFF2A2A2A),
            onClick = onSpotifyClick
        )
        FloatingRoundButton(
            icon = Icons.Filled.VolumeUp,
            background = Color(0xFF2A2A2A),
            onClick = onMuteClick
        )
    }
}

@Composable
private fun FloatingRoundButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    background: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(background)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = Color.White)
    }
}

/** Painel de controlo estilo o da imagem: capa, faixa, artista, prev/play/next. */
@Composable
fun MusicControlPanel(
    track: MusicTrackInfo?,
    connected: Boolean,
    onConnectClick: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF1A1A1A))
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1ED760)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    if (connected) "Abrir Spotify" else "Ligar ao Spotify",
                    color = Color(0xFF1ED760),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onConnectClick() }
                )
            }
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF2A2A2A)
            ) {
                Text(
                    "Aplicações de música",
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }

        if (track != null) {
            Spacer(Modifier.height(20.dp))
            Text(track.title, color = Color.White, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(track.artist, color = Color(0xFFB3B3B3), style = MaterialTheme.typography.bodyLarge)

            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Filled.SkipPrevious,
                    contentDescription = "Anterior",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp).clickable { onPrevious() }
                )
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable { onTogglePlay() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (track.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        contentDescription = "Play/Pause",
                        tint = Color.Black
                    )
                }
                Icon(
                    Icons.Filled.SkipNext,
                    contentDescription = "Seguinte",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp).clickable { onNext() }
                )
            }
        } else if (!connected) {
            Spacer(Modifier.height(12.dp))
            Text(
                "Liga a app ao Spotify para veres e controlares a música aqui.",
                color = Color(0xFFB3B3B3)
            )
        }
    }
}
