package com.roads.app.data

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

data class OsrmGeometry(val coordinates: List<List<Double>>, val type: String)
data class OsrmManeuver(val type: String, val modifier: String? = null, val location: List<Double> = emptyList())
data class OsrmStep(
    val distance: Double,
    val duration: Double,
    val name: String,
    val maneuver: OsrmManeuver
)
data class OsrmLeg(val steps: List<OsrmStep>)
data class OsrmRoute(
    val geometry: OsrmGeometry,
    val legs: List<OsrmLeg>,
    val distance: Double,
    val duration: Double
)
data class OsrmResponse(val code: String, val routes: List<OsrmRoute>?)

interface OsrmApi {
    @GET("route/v1/driving/{coords}")
    suspend fun route(
        @Path("coords") coords: String,
        @Query("overview") overview: String = "full",
        @Query("geometries") geometries: String = "geojson",
        @Query("steps") steps: Boolean = true
    ): OsrmResponse
}

/**
 * Usa o servidor demo público do OSRM (router.project-osrm.org).
 * É grátis e sem key, mas tem rate-limit para uso intenso — para produção real
 * o ideal é hospedar o teu próprio OSRM/Valhalla (também grátis, open-source).
 */
class RoutingRepository {

    private fun maneuverToText(m: OsrmManeuver): String = when (m.type) {
        "turn" -> when (m.modifier) {
            "left" -> "Vire à esquerda"
            "right" -> "Vire à direita"
            "slight left" -> "Ligeiramente à esquerda"
            "slight right" -> "Ligeiramente à direita"
            "sharp left" -> "Vire acentuadamente à esquerda"
            "sharp right" -> "Vire acentuadamente à direita"
            "uturn" -> "Inversão de marcha"
            else -> "Vire"
        }
        "roundabout" -> "Entre na rotunda"
        "merge" -> "Entre na via"
        "depart" -> "Siga em frente"
        "arrive" -> "Chegou ao destino"
        else -> "Siga em frente"
    }

    suspend fun getRoute(origin: LatLon, destination: LatLon): RouteResult? {
        return try {
            val coords = "${origin.lon},${origin.lat};${destination.lon},${destination.lat}"
            val response = NetworkClient.osrm.route(coords)
            val route = response.routes?.firstOrNull() ?: return null

            val geometry = route.geometry.coordinates.map { LatLon(it[1], it[0]) }
            val steps = route.legs.flatMap { it.steps }.map {
                RouteStep(
                    instruction = maneuverToText(it.maneuver),
                    distanceMeters = it.distance,
                    streetName = it.name.ifBlank { "" },
                    maneuver = it.maneuver.type,
                    location = if (it.maneuver.location.size >= 2)
                        LatLon(it.maneuver.location[1], it.maneuver.location[0])
                    else LatLon(origin.lat, origin.lon)
                )
            }

            RouteResult(
                geometry = geometry,
                steps = steps,
                distanceMeters = route.distance,
                durationSeconds = route.duration
            )
        } catch (e: Exception) {
            null
        }
    }
}
