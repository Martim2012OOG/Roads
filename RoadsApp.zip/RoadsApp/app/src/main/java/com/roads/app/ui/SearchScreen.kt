package com.roads.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.roads.app.data.FavoritePlace
import com.roads.app.data.PlaceResult

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    recents: List<FavoritePlace>,
    home: FavoritePlace?,
    work: FavoritePlace?,
    onQueryChanged: (String) -> Unit,
    results: List<PlaceResult>,
    onPlaceSelected: (PlaceResult) -> Unit,
    onRecentSelected: (FavoritePlace) -> Unit
) {
    var query by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Column(Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    onQueryChanged(it)
                },
                placeholder = { Text("Destino?") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = Color(0xFFF2F2F2),
                    focusedContainerColor = Color(0xFFF2F2F2),
                    unfocusedBorderColor = Color.Transparent,
                    focusedBorderColor = Color.Transparent
                )
            )
        }

        if (query.isNotBlank() && results.isNotEmpty()) {
            LazyColumn {
                items(results) { place ->
                    ListRow(
                        icon = Icons.Filled.Place,
                        title = place.displayName.substringBefore(","),
                        subtitle = place.displayName,
                        onClick = { onPlaceSelected(place) }
                    )
                    HorizontalDivider(color = Color(0xFFF0F0F0))
                }
            }
        } else {
            LazyColumn {
                item {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        FavoriteChip(
                            "Casa", Icons.Filled.Home,
                            defined = home != null,
                            onClick = { home?.let { onRecentSelected(it) } }
                        )
                        Spacer(Modifier.width(12.dp))
                        FavoriteChip(
                            "Trabalho", Icons.Filled.Work,
                            defined = work != null,
                            onClick = { work?.let { onRecentSelected(it) } }
                        )
                    }
                }
                if (recents.isNotEmpty()) {
                    item {
                        Text(
                            "Recentes",
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                    items(recents) { place ->
                        ListRow(
                            icon = Icons.Filled.History,
                            title = place.label,
                            subtitle = place.address,
                            onClick = { onRecentSelected(place) }
                        )
                        HorizontalDivider(color = Color(0xFFF0F0F0))
                    }
                }
            }
        }
    }
}

@Composable
private fun FavoriteChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, defined: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .background(Color(0xFFF2F2F2), RoundedCornerShape(16.dp))
            .clickable(enabled = defined) { onClick() }
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = Color(0xFFFF7A1F))
        Spacer(Modifier.height(6.dp))
        Text(label, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ListRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Color.Gray)
        Spacer(Modifier.width(16.dp))
        Column {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1)
        }
    }
}
