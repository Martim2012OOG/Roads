package com.roads.app.ui

import android.content.Context
import android.os.Bundle
import androidx.compose.runtime.*
import androidx.compose.ui.viewinterop.AndroidView
import com.roads.app.data.LatLon
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point

private const val ROUTE_SOURCE_ID = "roads-route-source"
private const val ROUTE_LAYER_ID = "roads-route-layer"

/** Guarda a referência ao mapa para o resto da app poder controlar câmara/rota. */
class RoadsMapController {
    var map: MapLibreMap? = null
        internal set
    var styleLoaded: Boolean = false
        internal set

    fun centerOn(lat: Double, lon: Double, zoom: Double = 16.5, animate: Boolean = true) {
        val cam = CameraPosition.Builder().target(LatLng(lat, lon)).zoom(zoom).build()
        if (animate) {
            map?.animateCamera(CameraUpdateFactory.newCameraPosition(cam), 600)
        } else {
            map?.cameraPosition = cam
        }
    }

    fun drawRoute(points: List<LatLon>) {
        val style = map?.style ?: return
        val line = LineString.fromLngLats(points.map { Point.fromLngLat(it.lon, it.lat) })
        val source = style.getSourceAs<GeoJsonSource>(ROUTE_SOURCE_ID)
        if (source != null) {
            source.setGeoJson(Feature.fromGeometry(line))
        } else {
            style.addSource(GeoJsonSource(ROUTE_SOURCE_ID, Feature.fromGeometry(line)))
            style.addLayer(
                LineLayer(ROUTE_LAYER_ID, ROUTE_SOURCE_ID).withProperties(
                    PropertyFactory.lineColor("#6C4DFF"),
                    PropertyFactory.lineWidth(6f),
                    PropertyFactory.lineCap(org.maplibre.android.style.layers.Property.LINE_CAP_ROUND),
                    PropertyFactory.lineJoin(org.maplibre.android.style.layers.Property.LINE_JOIN_ROUND)
                )
            )
        }
    }

    fun clearRoute() {
        val style = map?.style ?: return
        style.getSourceAs<GeoJsonSource>(ROUTE_SOURCE_ID)?.setGeoJson(FeatureCollectionEmpty())
    }

    private fun FeatureCollectionEmpty() =
        org.maplibre.geojson.FeatureCollection.fromFeatures(emptyList())
}

@Composable
fun RoadsMap(
    modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier,
    onMapReady: (RoadsMapController) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    remember { MapLibre.getInstance(context) }

    val mapView = remember { MapView(context) }
    val controller = remember { RoadsMapController() }

    DisposableEffect(Unit) {
        mapView.onCreate(Bundle())
        mapView.onStart()
        mapView.onResume()
        onDispose {
            mapView.onPause()
            mapView.onStop()
            mapView.onDestroy()
        }
    }

    AndroidView(modifier = modifier, factory = {
        mapView.getMapAsync { map ->
            controller.map = map
            map.setStyle(Style.Builder().fromUri("asset://style.json")) { _ ->
                controller.styleLoaded = true
                onMapReady(controller)
            }
        }
        mapView
    })
}
