package com.roads.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.roads.app.data.RouteResult

/** Cartão em baixo com resumo da rota + botão "Iniciar" (como na imagem de referência). */
@Composable
fun RoutePreviewCard(
    route: RouteResult,
    destinationLabel: String,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val minutes = (route.durationSeconds / 60).toInt()
    val km = route.distanceMeters / 1000.0

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .padding(20.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onCancel) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
            }
            Text(destinationLabel, fontWeight = FontWeight.Bold, maxLines = 1)
            Spacer(Modifier.width(48.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text("$minutes min", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "%.1f km".format(km),
            color = Color.Gray
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onStart,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(26.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF7A1F))
        ) {
            Text("Iniciar", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Faixa preta superior com a próxima manobra, tal como no Waze. */
@Composable
fun ManeuverBanner(
    instruction: String,
    streetName: String,
    distanceMeters: Double,
    modifier: Modifier = Modifier
) {
    val distanceText = if (distanceMeters >= 1000) {
        "%.1f km".format(distanceMeters / 1000.0)
    } else {
        "${distanceMeters.toInt()} m"
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF121212))
            .padding(horizontal = 20.dp, vertical = 24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.TurnRight,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(40.dp)
        )
        Spacer(Modifier.width(16.dp))
        Column {
            Text(distanceText, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(
                if (streetName.isNotBlank()) streetName else instruction,
                color = Color(0xFF4DA8FF),
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

/** Círculo de velocidade atual, com aviso vermelho se ultrapassar o limite. */
@Composable
fun SpeedBadge(currentKmh: Int, speedLimitKmh: Int?, modifier: Modifier = Modifier) {
    val overLimit = speedLimitKmh != null && currentKmh > speedLimitKmh
    Box(
        modifier = modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(if (overLimit) Color(0xFFFF4B4B) else Color(0xFF2A2A2A)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$currentKmh", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("km/h", color = Color.White, fontSize = 10.sp)
        }
    }
}

/** Botão amarelo de reportar, igual ao Waze. */
@Composable
fun ReportButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(64.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFFFC107))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Filled.Add, contentDescription = "Reportar", tint = Color.Black)
    }
}

/** Barra inferior com ETA, tempo e distância + botão de sair. */
@Composable
fun EtaBar(
    minutesRemaining: Int,
    kmRemaining: Double,
    arrivalTime: String,
    onStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .padding(horizontal = 24.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(arrivalTime, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("$minutesRemaining min · %.1f km".format(kmRemaining), color = Color.Gray)
        }
        IconButton(onClick = onStop) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFF2F2F2)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Close, contentDescription = "Terminar")
            }
        }
    }
}
