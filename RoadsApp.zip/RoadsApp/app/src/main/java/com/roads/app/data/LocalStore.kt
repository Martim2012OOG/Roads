package com.roads.app.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * Guarda dados localmente (SharedPreferences + JSON), para que a app continue
 * a funcionar 100% offline: última posição conhecida, alertas reportados,
 * favoritos (Casa/Trabalho) e histórico de pesquisas recentes.
 */
class LocalStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("roads_store", Context.MODE_PRIVATE)
    private val gson = Gson()

    // --- Última localização conhecida (para funcionar sem GPS/rede) ---
    fun saveLastLocation(lat: Double, lon: Double) {
        prefs.edit()
            .putFloat("last_lat", lat.toFloat())
            .putFloat("last_lon", lon.toFloat())
            .apply()
    }

    fun getLastLocation(): LatLon? {
        if (!prefs.contains("last_lat")) return null
        return LatLon(
            prefs.getFloat("last_lat", 0f).toDouble(),
            prefs.getFloat("last_lon", 0f).toDouble()
        )
    }

    // --- Favoritos: Casa / Trabalho ---
    fun saveFavorite(key: String, place: FavoritePlace) {
        prefs.edit().putString("fav_$key", gson.toJson(place)).apply()
    }

    fun getFavorite(key: String): FavoritePlace? {
        val json = prefs.getString("fav_$key", null) ?: return null
        return gson.fromJson(json, FavoritePlace::class.java)
    }

    // --- Recentes ---
    fun addRecent(place: FavoritePlace) {
        val list = getRecents().toMutableList()
        list.removeAll { it.address == place.address }
        list.add(0, place)
        val trimmed = list.take(10)
        prefs.edit().putString("recents", gson.toJson(trimmed)).apply()
    }

    fun getRecents(): List<FavoritePlace> {
        val json = prefs.getString("recents", null) ?: return emptyList()
        val type = object : TypeToken<List<FavoritePlace>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    // --- Alertas reportados pelo utilizador (trânsito, polícia, radar, etc) ---
    fun addAlert(alert: MapAlert) {
        val list = getAlerts().toMutableList()
        list.add(alert)
        prefs.edit().putString("alerts", gson.toJson(list)).apply()
    }

    fun getAlerts(): List<MapAlert> {
        val json = prefs.getString("alerts", null) ?: return emptyList()
        val type = object : TypeToken<List<MapAlert>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    /** Remove alertas com mais de 3 horas (trânsito/acidentes deixam de ser relevantes). */
    fun purgeOldAlerts() {
        val cutoff = System.currentTimeMillis() - (3 * 60 * 60 * 1000)
        val fresh = getAlerts().filter {
            it.timestampMillis > cutoff || it.type == AlertType.RADAR
        }
        prefs.edit().putString("alerts", gson.toJson(fresh)).apply()
    }
}
