package com.roads.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.roads.app.data.*
import com.roads.app.location.LocationTracker
import com.roads.app.location.NavLocation
import com.roads.app.location.NavigationForegroundService
import com.roads.app.music.SpotifyController
import com.roads.app.ui.*
import com.roads.app.voice.VoiceGuide
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private enum class Screen { PERMISSION, SEARCH, PREVIEW, NAVIGATING }

class MainActivity : ComponentActivity() {

    private lateinit var locationTracker: LocationTracker
    private lateinit var localStore: LocalStore
    private lateinit var voiceGuide: VoiceGuide
    private lateinit var spotifyController: SpotifyController
    private val geocodingRepository = GeocodingRepository()
    private val routingRepository = RoutingRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        locationTracker = LocationTracker(this)
        localStore = LocalStore(this)
        voiceGuide = VoiceGuide(this)
        spotifyController = SpotifyController(this)

        setContent {
            MaterialTheme {
                RoadsApp(
                    locationTracker = locationTracker,
                    localStore = localStore,
                    voiceGuide = voiceGuide,
                    spotifyController = spotifyController,
                    geocodingRepository = geocodingRepository,
                    routingRepository = routingRepository,
                    hasLocationPermission = { hasLocationPermission() },
                    requestLocationPermission = { callback -> requestLocationPermission(callback) },
                    startNavService = {
                        val intent = Intent(this, NavigationForegroundService::class.java)
                        ContextCompat.startForegroundService(this, intent)
                    },
                    stopNavService = {
                        stopService(Intent(this, NavigationForegroundService::class.java))
                    }
                )
            }
        }
    }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private var onPermissionResult: ((Boolean) -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true
        onPermissionResult?.invoke(granted)
    }

    private fun requestLocationPermission(onResult: (Boolean) -> Unit) {
        onPermissionResult = onResult
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceGuide.shutdown()
        spotifyController.disconnect()
    }
}

@Composable
private fun RoadsApp(
    locationTracker: LocationTracker,
    localStore: LocalStore,
    voiceGuide: VoiceGuide,
    spotifyController: SpotifyController,
    geocodingRepository: GeocodingRepository,
    routingRepository: RoutingRepository,
    hasLocationPermission: () -> Boolean,
    requestLocationPermission: ((Boolean) -> Unit) -> Unit,
    startNavService: () -> Unit,
    stopNavService: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf(if (hasLocationPermission()) Screen.SEARCH else Screen.PERMISSION) }
    var permissionDenied by remember { mutableStateOf(false) }

    var mapController by remember { mutableStateOf<RoadsMapController?>(null) }
    var currentNav by remember { mutableStateOf<NavLocation?>(null) }

    var searchResults by remember { mutableStateOf<List<PlaceResult>>(emptyList()) }
    var recents by remember { mutableStateOf(localStore.getRecents()) }
    var home by remember { mutableStateOf(localStore.getFavorite("home")) }
    var work by remember { mutableStateOf(localStore.getFavorite("work")) }

    var activeRoute by remember { mutableStateOf<RouteResult?>(null) }
    var destinationLabel by remember { mutableStateOf("") }
    var stepIndex by remember { mutableIntStateOf(0) }
    var showAlertSheet by remember { mutableStateOf(false) }

    var trackInfo by remember { mutableStateOf(spotifyController.trackInfo.value) }
    var spotifyConnected by remember { mutableStateOf(false) }
    var showMusicPanel by remember { mutableStateOf(false) }

    // Começa a ouvir a localização assim que há permissão.
    LaunchedEffect(screen) {
        if (screen != Screen.PERMISSION) {
            // Usa a última posição guardada imediatamente (funciona offline / sem GPS ainda fixado)
            locationTracker.lastKnownOrCached()?.let { cached ->
                mapController?.centerOn(cached.lat, cached.lon, animate = false)
            }
            locationTracker.observeLocation().collect { nav ->
                currentNav = nav
                if (screen == Screen.NAVIGATING) {
                    mapController?.centerOn(nav.latLon.lat, nav.latLon.lon, zoom = 18.0)

                    activeRoute?.let { route ->
                        if (stepIndex < route.steps.size) {
                            val step = route.steps[stepIndex]
                            val dist = GeoUtils.distanceMeters(nav.latLon, step.location)
                            if (dist < 35 && stepIndex < route.steps.size - 1) {
                                stepIndex += 1
                                val next = route.steps[stepIndex]
                                voiceGuide.speak("${next.instruction} em ${next.streetName.ifBlank { "seguida" }}")
                            }
                        }
                    }
                } else {
                    mapController?.centerOn(nav.latLon.lat, nav.latLon.lon)
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        spotifyController.trackInfo.collect { trackInfo = it }
    }
    LaunchedEffect(Unit) {
        spotifyController.connected.collect { spotifyConnected = it }
    }

    Box(Modifier.fillMaxSize()) {
        RoadsMap(modifier = Modifier.fillMaxSize()) { controller ->
            mapController = controller
        }

        when (screen) {
            Screen.PERMISSION -> PermissionScreen(
                denied = permissionDenied,
                onRequest = {
                    requestLocationPermission { granted ->
                        if (granted) {
                            screen = Screen.SEARCH
                        } else {
                            permissionDenied = true
                        }
                    }
                }
            )

            Screen.SEARCH -> {
                Column(Modifier.fillMaxSize()) {
                    Spacer(Modifier.weight(1f))
                    Surface(
                        color = Color.White,
                        modifier = Modifier.fillMaxHeight(0.85f)
                    ) {
                        SearchScreen(
                            recents = recents,
                            home = home,
                            work = work,
                            results = searchResults,
                            onQueryChanged = { query ->
                                scope.launch {
                                    searchResults = geocodingRepository.search(query)
                                }
                            },
                            onPlaceSelected = { place ->
                                destinationLabel = place.displayName.substringBefore(",")
                                val fav = FavoritePlace(destinationLabel, place.displayName, place.lat, place.lon)
                                localStore.addRecent(fav)
                                recents = localStore.getRecents()
                                val origin = currentNav?.latLon ?: locationTracker.lastKnownOrCached()
                                if (origin != null) {
                                    scope.launch {
                                        val route = routingRepository.getRoute(origin, LatLon(place.lat, place.lon))
                                        if (route != null) {
                                            activeRoute = route
                                            stepIndex = 0
                                            mapController?.drawRoute(route.geometry)
                                            screen = Screen.PREVIEW
                                        }
                                    }
                                }
                            },
                            onRecentSelected = { place ->
                                val origin = currentNav?.latLon ?: locationTracker.lastKnownOrCached()
                                if (origin != null) {
                                    scope.launch {
                                        val route = routingRepository.getRoute(origin, LatLon(place.lat, place.lon))
                                        if (route != null) {
                                            activeRoute = route
                                            destinationLabel = place.label
                                            stepIndex = 0
                                            mapController?.drawRoute(route.geometry)
                                            screen = Screen.PREVIEW
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }

            Screen.PREVIEW -> {
                activeRoute?.let { route ->
                    Column(Modifier.fillMaxSize()) {
                        Spacer(Modifier.weight(1f))
                        RoutePreviewCard(
                            route = route,
                            destinationLabel = destinationLabel,
                            onStart = {
                                screen = Screen.NAVIGATING
                                startNavService()
                                voiceGuide.speak("A iniciar navegação para $destinationLabel")
                            },
                            onCancel = {
                                activeRoute = null
                                mapController?.clearRoute()
                                screen = Screen.SEARCH
                            }
                        )
                    }
                }
            }

            Screen.NAVIGATING -> {
                activeRoute?.let { route ->
                    val step = route.steps.getOrNull(stepIndex)
                    val distToStep = if (step != null && currentNav != null)
                        GeoUtils.distanceMeters(currentNav!!.latLon, step.location) else 0.0

                    Column(Modifier.fillMaxSize()) {
                        ManeuverBanner(
                            instruction = step?.instruction ?: "Siga em frente",
                            streetName = step?.streetName ?: "",
                            distanceMeters = distToStep
                        )

                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            MusicFloatingButtons(
                                connected = spotifyConnected,
                                onSpotifyClick = {
                                    if (spotifyConnected) {
                                        showMusicPanel = !showMusicPanel
                                    } else {
                                        spotifyController.connect()
                                    }
                                },
                                onMuteClick = { /* alterna volume de avisos, extensível */ },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(16.dp)
                            )
                            SpeedBadge(
                                currentKmh = currentNav?.speedKmh ?: 0,
                                speedLimitKmh = null,
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(16.dp)
                            )
                            ReportButton(
                                onClick = { showAlertSheet = true },
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(16.dp)
                            )
                        }

                        if (showMusicPanel) {
                            MusicControlPanel(
                                track = trackInfo,
                                connected = spotifyConnected,
                                onConnectClick = { if (!spotifyConnected) spotifyController.connect() },
                                onTogglePlay = { spotifyController.togglePlayPause() },
                                onNext = { spotifyController.skipNext() },
                                onPrevious = { spotifyController.skipPrevious() }
                            )
                        }

                        val remainingMeters = route.distanceMeters
                        val eta = remember(route) {
                            val cal = Calendar.getInstance()
                            cal.add(Calendar.SECOND, route.durationSeconds.toInt())
                            SimpleDateFormat("HH:mm", Locale.getDefault()).format(cal.time)
                        }
                        EtaBar(
                            minutesRemaining = (route.durationSeconds / 60).toInt(),
                            kmRemaining = remainingMeters / 1000.0,
                            arrivalTime = eta,
                            onStop = {
                                activeRoute = null
                                mapController?.clearRoute()
                                stopNavService()
                                screen = Screen.SEARCH
                            }
                        )
                    }

                    if (showAlertSheet) {
                        AlertSheet(
                            onDismiss = { showAlertSheet = false },
                            onAlertChosen = { type ->
                                currentNav?.let { nav ->
                                    localStore.addAlert(
                                        MapAlert(type = type, lat = nav.latLon.lat, lon = nav.latLon.lon)
                                    )
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionScreen(denied: Boolean, onRequest: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.LocationOn,
            contentDescription = null,
            tint = Color(0xFFFF7A1F),
            modifier = Modifier.size(64.dp)
        )
        Spacer(Modifier.height(20.dp))
        Text(
            "A Roads precisa da tua localização",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Para te mostrar o mapa, calcular rotas e dar indicações por voz, a app precisa de aceder ao GPS.",
            textAlign = TextAlign.Center,
            color = Color.Gray
        )
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onRequest,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF7A1F))
        ) {
            Text("Ativar localização")
        }
        if (denied) {
            Spacer(Modifier.height(16.dp))
            Text(
                "Sem esta permissão a Roads não consegue navegar. Podes ativá-la nas Definições do telemóvel.",
                color = Color(0xFFFF4B4B),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
