package com.roads.app.music

import android.content.Context
import com.spotify.android.appremote.api.ConnectionParams
import com.spotify.android.appremote.api.Connector
import com.spotify.android.appremote.api.SpotifyAppRemote
import com.spotify.protocol.types.PlayerState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * IMPORTANTE:
 * 1. Precisas de criar uma app grátis em https://developer.spotify.com/dashboard
 * 2. Regista o "Application Fingerprint" (package name com.roads.app + SHA1 da tua
 *    keystore) nas definições da app no dashboard, senão o App Remote recusa a ligação.
 * 3. Substitui SPOTIFY_CLIENT_ID abaixo pelo Client ID que o dashboard te dá.
 * 4. O utilizador precisa de ter a app do Spotify instalada e sessão iniciada -
 *    o controlo é sempre da música que já está a tocar lá, não requer premium
 *    para leitura de estado, mas alguns comandos (skip) podem precisar de Premium.
 */
object SpotifyConfig {
    const val CLIENT_ID = "f67c3c3af1af4875aca59b79d1da24d5"
    const val REDIRECT_URI = "roadsapp://spotify-callback"
}

data class MusicTrackInfo(
    val title: String,
    val artist: String,
    val isPaused: Boolean,
    val imageUri: String?
)

class SpotifyController(private val context: Context) {

    private var appRemote: SpotifyAppRemote? = null

    private val _trackInfo = MutableStateFlow<MusicTrackInfo?>(null)
    val trackInfo: StateFlow<MusicTrackInfo?> = _trackInfo.asStateFlow()

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    fun connect(onResult: (Boolean) -> Unit = {}) {
        val params = ConnectionParams.Builder(SpotifyConfig.CLIENT_ID)
            .setRedirectUri(SpotifyConfig.REDIRECT_URI)
            .showAuthView(true)
            .build()

        SpotifyAppRemote.connect(context, params, object : Connector.ConnectionListener {
            override fun onConnected(remote: SpotifyAppRemote) {
                appRemote = remote
                _connected.value = true
                subscribeToPlayerState()
                onResult(true)
            }

            override fun onFailure(throwable: Throwable) {
                _connected.value = false
                onResult(false)
            }
        })
    }

    private fun subscribeToPlayerState() {
        appRemote?.playerApi?.subscribeToPlayerState()?.setEventCallback { state: PlayerState ->
            val track = state.track
            _trackInfo.value = if (track != null) {
                MusicTrackInfo(
                    title = track.name,
                    artist = track.artist.name,
                    isPaused = state.isPaused,
                    imageUri = track.imageUri?.raw
                )
            } else null
        }
    }

    fun togglePlayPause() {
        val remote = appRemote ?: return
        val paused = _trackInfo.value?.isPaused ?: return
        if (paused) remote.playerApi.resume() else remote.playerApi.pause()
    }

    fun skipNext() {
        appRemote?.playerApi?.skipNext()
    }

    fun skipPrevious() {
        appRemote?.playerApi?.skipPrevious()
    }

    fun disconnect() {
        appRemote?.let { SpotifyAppRemote.disconnect(it) }
        appRemote = null
        _connected.value = false
    }

    fun isSpotifyInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo("com.spotify.music", 0)
            true
        } catch (e: Exception) {
            false
        }
    }
}
