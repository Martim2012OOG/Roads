package com.roads.app.data

import retrofit2.http.GET
import retrofit2.http.Query

data class NominatimResult(
    val display_name: String,
    val lat: String,
    val lon: String
)

interface NominatimApi {
    @GET("search")
    suspend fun search(
        @Query("q") query: String,
        @Query("format") format: String = "json",
        @Query("limit") limit: Int = 6,
        @Query("countrycodes") countryCodes: String = "pt"
    ): List<NominatimResult>
}

class GeocodingRepository {
    suspend fun search(query: String): List<PlaceResult> {
        if (query.isBlank()) return emptyList()
        return try {
            NetworkClient.nominatim.search(query).map {
                PlaceResult(
                    displayName = it.display_name,
                    lat = it.lat.toDouble(),
                    lon = it.lon.toDouble()
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
